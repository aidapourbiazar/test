package com.fxinnovation.seleniumqa.test;

import org.junit.Test;

import com.fxinnovation.seleniumqa.test.common.TestBaseSetup;
import com.fxinnovation.seleniumqa.test.page.LunchPage;


public class LunchPageTest extends TestBaseSetup {
	
	@Test
	public void luchApp(){
		LunchPage lunch=new LunchPage(getWebDriver());
		lunch.clickOnLunch();
	}

}
