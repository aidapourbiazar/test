package com.fxinnovation.seleniumqa.test.page;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.fxinnovation.seleniumqa.util.ConfigReader;

public class LunchPage {
	private WebDriver driver;
	private ConfigReader configReader = ConfigReader.getInstance();
	private Properties objectRepository;
	
	public LunchPage(WebDriver driver){
		this.driver=driver;
		
		objectRepository = configReader.getProperties("or.preoperties");
	}
	
	public void clickOnLunch() {
		driver.findElement(By.id(objectRepository.getProperty("lunchButton"))).click();
	}
	
}
