package com.fxinnovation.seleniumqa.test.pack.pageobjects;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.fxinnovation.seleniumqa.util.ConfigReader;

public class CommonOperations {

	/*private WebDriver driver;
	private ConfigReader configReader = ConfigReader.getInstance();
	private Properties objectRepository;

	public CommonOperations(WebDriver driver)
	{
		this.driver=driver;		
		objectRepository = configReader.getProperties("or.properties");
	}
}
	public String clickElementByID(ElementID )
	{     //APP_LOGS.debug("Clicking on link ");
    try{
        driver.findElement(By.ID(or.getProperty(ElementID))).click();
        }catch(Exception e){
         return Constants.KEYWORD_FAIL+" -- Not able to click on link"+e.getMessage();
    }*/

}